/* ----------------------------------------------------------------- *
* PROGRAM-ID.	BMPLEX.C					     *
* AUTHOR.	ARIMAC.	/ patched by tantan			     *
* DATE-WRITTEN.	1992.10.07 / 2022.12.20				     *
* REMARKS.							     *
*								     *
*�@�EMS-Windows �� BMP �t�@�C����\������B			     *
*�@�E�������A�Q�^�P�U�^�Q�T�U�^�P�U�V�W���F�񈳏k�̃t�@�C���̂�	     *
*�@�@�Ή��B							     *
*								     *
* HISTORY.							     *
*								     *
*�@ 1992.10.07	v0.10 ���J					     *
*								     *
*�@ 1992.12.10	v0.20 �Q�F�f�[�^�ɑΉ������B			     *
*		      �X�N���[�������𔽓]�o����悤�ɂ����B	     *
*								     *
*�@ 1994.03.07	v0.32 �P�U�V�W���F�f�[�^�ɑΉ������B		     *
*		      ���C���h�J�[�h�w��ɑΉ������B		     *
*								     *
*�@ 1994.03.12	v0.33 1678���F�摜�̃��C���������O���[�h�o�E���_���� *
*		      �؂�グ��l�ɂ��Ă݂��B			     *
*		      �i�ؗF�D���̕񍐂ɂ��B�j		     *
*                                                                    *
*�@ 2022.12.22  v0.33.1 XEiJ �̊g�����[�h7�ɑΉ���1678���F�f�[�^��   *
*                       �ő�1024x1024�T�C�Y�\���ɑΉ������B(tantan)  *  
*								     *
* ----------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stat.h>
#include <io.h>
#include <string.h>
#include <jstring.h>
#include <iocslib.h>
#include <doslib.h>
#include "ARIMAC.H"

/* ---------------------------------------------------------------- */

#define __EXT_GVRAM__ 1

#ifdef __GNUC__ 
#define alloca(x)	__builtin_alloca ( x )
#else
#define alloca(x)	malloc(x)
#endif

#define mbsizeof(TYPE,MEMBER)	(sizeof((TYPE *)0)->MEMBER)
#define swap_parm(TYPE,MEMBER)	offsetof(TYPE,MEMBER),mbsizeof(TYPE,MEMBER)

typedef unsigned char  uchar ;
typedef unsigned short ushort ;
typedef unsigned long  ulong ;

/* ---------------------------------------------------------------- */

#define RGB(wr,wg,wb)		(((((wg)<<5|(wr))<<5|(wb))<<1)+1)

#define VRAM4_XL	1024	/* vram size [dot] */
#define VRAM4_YL	1024

#define VRAM8_XL	512	/* vram size [dot] */
#define VRAM8_YL	512

#define SCRN_XL		768	/* screen size [dot] */
#define SCRN_YL		512

typedef ushort T_GVRAM ;
#define GVRAM	( ( T_GVRAM * ) 0xC00000 )

/* ---------------------------------------------------------------- */

typedef struct {
  ushort bfType ;
  ulong  bfSize ;
  ushort bfReserved1 ;
  ushort bfReserved2 ;
  ulong  bfOffBits ;
} BITMAP_FILE_HEADER ;

static uchar bmp_fil_hdr_swap [ ] = {
  swap_parm ( BITMAP_FILE_HEADER , bfSize    ) ,
  swap_parm ( BITMAP_FILE_HEADER , bfOffBits ) ,
} ;

/* ---------------------------------------------------------------- */

typedef struct {
  ulong  biSize ;
  ulong  biWidth ;
  ulong  biHeight ;
  ushort biPlanes ;
  ushort biBitCount ;
  ulong  biCompression ;
  ulong  biSizeImage ;
  ulong  biXPelsPerMeter ;
  ulong  biYPelsPerMeter ;
  ulong  biClrUsed ;
  ulong  biClrImportant ;
} BITMAP_INFO_HEADER ;

static uchar bmp_inf_hdr_swap [ ] = {
  swap_parm ( BITMAP_INFO_HEADER , biSize          ) ,
  swap_parm ( BITMAP_INFO_HEADER , biWidth         ) ,
  swap_parm ( BITMAP_INFO_HEADER , biHeight        ) ,
  swap_parm ( BITMAP_INFO_HEADER , biPlanes        ) ,
  swap_parm ( BITMAP_INFO_HEADER , biBitCount      ) ,
  swap_parm ( BITMAP_INFO_HEADER , biCompression   ) ,
  swap_parm ( BITMAP_INFO_HEADER , biSizeImage     ) ,
  swap_parm ( BITMAP_INFO_HEADER , biXPelsPerMeter ) ,
  swap_parm ( BITMAP_INFO_HEADER , biYPelsPerMeter ) ,
  swap_parm ( BITMAP_INFO_HEADER , biClrUsed  	   ) ,
  swap_parm ( BITMAP_INFO_HEADER , biClrImportant  ) ,
} ;

/* ---------------------------------------------------------------- */

typedef struct {
  uchar rgbBlue ;
  uchar rgbGreen ;
  uchar rgbRed ;
  uchar rgbReserved ;
} RGB_QUAD ;

/* ---------------------------------------------------------------- */
static int info_mode = 0 ;	/* 1:���\�����[�h */
static int clr_mode = 0 ;	/* 1:�P�t�@�C�����ɉ�ʂ��N���A����B */
static int fill_mode = 0 ;	/* 1:�~���l�ߕ\�����s�Ȃ��B */
static int cent_mode = 0 ;	/* 1:�Z���^�����O���[�h */
static int wait_mode = 0 ;	/* 1:�L�[���͑҂����[�h */
static int rev_mode = 0 ;	/* 1:�X�N���[���������](MAG��) */
#ifdef __EXT_GVRAM__
static int exg_mode = 0 ;       /* 1:XEiJ��p�g���O���t�B�b�N��ʂ��g�p���� */
static int random_mode = 0 ;    /* 1:�w�肳�ꂽ�t�@�C�����烉���_����1�������\������ */
#endif
static int path_dlm = '\\' ;	/* �p�X�̋�؂蕶�� */

static int load_x1 = 0 ;	/* loading offset */
static int load_y1 = 0 ;

static int disp_value = 100 ;	/* ���邳(0�`100)[%] */
static int exit_flag = 0 ;
static int disp_mode = 0 ;	/* �O�f�[�^�̉�ʃ��[�h(1:16�F, 4:256�F, 5:1678���F) */
static int scrn_mode = 0 ;
static int tx_use = 0 ;

#define IOBUF_SZ1	( 8 * 1024 )
static long iobuf_cnt1 = 0 ;
static uchar * iobuf_pt1 ;
static uchar iobuf1 [ IOBUF_SZ1 ] ;

static T_GVRAM red_cnv_tbl [ 256 ] ;
static T_GVRAM green_cnv_tbl [ 256 ] ;
static T_GVRAM blue_cnv_tbl [ 256 ] ;

/* ---------------------------------------------------------------- */

static void ( * xc_abort_proc1 ) ( void ) ;
static void ( * xc_abort_proc2 ) ( void ) ;

/* ---------------------------------------------------------------- */

static int x_arg_chk ( int argc , uchar * argv [ ] ) ;
static void x_print_help ( int argc , uchar * argv [ ] ) ;
static void mk_cnvtbl ( void ) ;
static int x_file_proc ( uchar * fname_pt1 , int no_wild ) ;
static int x_bmp_load ( uchar * bmp_fname_pt1 ) ;

static void x_swap_bytes ( void * buf_pt1 , uchar * ctl_pt1 , int cnt1 ) ;
static void x_chg_crt_mode ( BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ) ;
static void x_ret_crt_mode ( void ) ;
static void x_ret_tx_mode ( void ) ;

static int x_read_palette ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ) ;

static int x_read_image1 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 ) ;

static int x_read_image4 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 ) ;

static int x_read_image8 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 ) ;

static int x_read_image24 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 ) ;

#ifdef __EXT_GVRAM__
static int x_read_image24ex ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 ) ;
#endif

static void x_store_image24 ( T_GVRAM * vram_pt1 , uchar * img_pt1 , int sxl1 ) ;
static int x_read ( int fh1 , uchar * buf_pt1 , int wlen1 ) ;
static void vram_copy ( T_GVRAM * vram_pt1 , T_GVRAM * vram_pt2 ) ;

static void x_set_abort_exit ( void ) ;
static void x_reset_abort_exit ( void ) ;
static void my_abort_proc1 ( void ) ;
static void my_abort_proc2 ( void ) ;

static void x_fill16 ( BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 , int ox1 , int oy1 ) ;
static void img_copy16 ( int sx1 , int sy1 , int sx2 , int sy2 ,
    BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ) ;
static void quick_copy ( T_GVRAM * vram_pt1 , T_GVRAM * vram_pt2 , int wlen1 ) ;

static void x_key_wait ( int wmode1 , int ox1 , int oy1 ) ;
static void x_scroll ( int wmode1 , int sx1 , int sy1 ) ;
static void g_scroll ( int wmode1 , int sx1 , int sy1 ) ;
static void tx_fill ( int pg1 , int sx1 , int sy1 , int ex1 , int ey1 , int pt1 ) ;

/* ---------------------------------------------------------------- */

global void main ( int argc , uchar * argv [ ] )
begin
  int retc , ix1 , fcnt1 , wch1 ;
  uchar * ch_pt1 ;
#ifdef __EXT_GVRAM__
  int file_selected = -1 ;
#endif

#ifdef __EXT_GVRAM__
  puts ( "X68k BMPLEX v0.33.1 Copyright 1992,2022 Arimac,tantan" ) ;
  puts ( "BMP File Loader (2/16/256/16M Colors)" ) ;
#else
  puts ( "X68k BMPL v0.33 Copyright 1992 Arimac" ) ;
  puts ( "BMP File Loader (2/16/256/16M Colors)" ) ;
#endif

  if ( x_arg_chk ( argc , argv ) != 0 ) goto lb600 ;

  if ( info_mode != 0 ) then
    retc = TGUSEMD ( 0 , - 1 ) ;
    if ( retc == 1 or retc == 2 ) then
      puts ( "�O���t�B�b�N�u�q�`�l�͎g�p���ł��B" ) ;
      goto lb800 ;
    endif_
  endif_

  mk_cnvtbl ( ) ;

  fcnt1 = 0 ;
  exit_flag = 0 ;

#ifdef __EXT_GVRAM__
  if ( random_mode != 0 ) then
    for ( ix1 = 1 ; ix1 < argc ; ix1 ++ ) begin
      ch_pt1 = argv [ ix1 ] ;
      wch1 = * ch_pt1 ;
      if ( wch1 == '-' or wch1 == '/' ) then
      else_
        fcnt1++;
      endif_
    endfor
    srand( ( unsigned int ) time ( NULL ) );
    file_selected = rand() % fcnt1 ;
    fcnt1 = 0 ;
  endif_
#endif

  for ( ix1 = 1 ; ix1 < argc ; ix1 ++ ) begin
    ch_pt1 = argv [ ix1 ] ;
    wch1 = * ch_pt1 ;
    if ( wch1 == '-' or wch1 == '/' ) then
      if ( ch_pt1 [ 1 ] == 0 ) then
        if ( ++ ix1 >= argc ) goto lb600 ;
        if ( x_file_proc ( argv [ ix1 ] , 1 ) != 0 ) goto lb800 ;
        fcnt1 ++ ;
      endif_
    else_
#ifdef __EXT_GVRAM__
      if ( random_mode == 0 or fcnt1 == file_selected ) then
        if ( x_file_proc ( ch_pt1 , 0 ) != 0 ) goto lb800 ;
      endif_	
#else
      if ( x_file_proc ( ch_pt1 , 0 ) != 0 ) goto lb800 ;
#endif
      fcnt1 ++ ;
    endif_
    if ( exit_flag != 0 ) break ;
  endfor

  x_ret_crt_mode ( ) ;
  if ( fcnt1 <= 0 ) goto lb600 ;
  exit ( EXIT_SUCCESS ) ;

lb600 :
  x_print_help ( argc , argv ) ;

lb800 :
  x_ret_crt_mode ( ) ;
  exit ( EXIT_FAILURE ) ;
end

/* ---------------------------------------------------------------- */

static int x_arg_chk ( int argc , uchar * argv [ ] )
begin
  int ix1 , wch1 , wk1 ;
  uchar * ch_pt1 ;

  for ( ix1 = 1 ; ix1 < argc ; ix1 ++ ) begin
    ch_pt1 = argv [ ix1 ] ;
    wch1 = * ch_pt1 ++ ;
    if ( wch1 == '-' or wch1 == '/' ) then
      switch ( * ch_pt1 ++ ) of
      case 'c' : case 'C' : clr_mode = 1 ;	break ;
      case 'f' : case 'F' : fill_mode = 1 ;	break ;
      case 'i' : case 'I' : info_mode = 1 ;	break ;
      case 'k' : case 'K' : wait_mode = 1 ;	break ;
      case 'n' : case 'N' : cent_mode = 1 ;	break ;
      case 'p' : case 'P' : path_dlm = '/' ;	break ;
      case 'r' : case 'R' : rev_mode = 1 ;	break ;
#ifdef __EXT_GVRAM__
      case 'e' : case 'E' : exg_mode = 1 ;	break ;
      case 'z' : case 'Z' : random_mode = 1 ;	break ;
#endif
      case 'v' : case 'V' :
        if ( sscanf ( ( char * ) ch_pt1 , "%d" , & wk1 ) != 1 ) wk1 = 50 ;
        if ( wk1 < 0 ) wk1 = 0 ;
        if ( wk1 > 100 ) wk1 = 100 ;
        disp_value = wk1 ;
        break ;
      case 'l' : case 'L' :
        if ( sscanf ( ( char * ) ch_pt1 , "%d,%d" ,
             & load_x1 , & load_y1 ) != 2 ) goto lb800 ;
        break ;
      case 0 :
        if ( ++ ix1 >= argc ) goto lb800 ;
        break ;
      default :
        goto lb800 ;
      endswitch
    endif_
  endfor

  return ( 0 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */

static void x_print_help ( int argc , uchar * argv [ ] )
begin
  int wlen1 ;
  uchar * ch_pt1 , * ch_pt2 ;

  if ( argc > 0 ) then
    ch_pt1 = argv [ 0 ] ;
    if ( ( ch_pt2 = jstrrchr ( ch_pt1 , '\\' ) ) == NULL ) then
      ch_pt2 = ch_pt1 ;
     else_
      ch_pt2 ++ ;
    endif_
    if ( ( ch_pt1 = jstrrchr ( ch_pt2 , '.' ) ) != NULL ) then
      wlen1 = ch_pt1 - ch_pt2 ;
      ch_pt1 = ( uchar * ) alloca ( wlen1 + 1 ) ;
      memcpy ( ( void * ) ch_pt1 , ( void * ) ch_pt2 , ( size_t ) wlen1 ) ;
      ch_pt1 [ wlen1 ] = 0 ;
      ch_pt2 = ch_pt1 ;
    endif_
   else_
    ch_pt2 = ( uchar * ) "BMPL" ;
  endif_

  printf ( "�g�p�@�F%s�m�X�C�b�`�n�c�m�t�@�C����[.BMP]�n�c\n" , ch_pt2 ) ;
  puts ( "\t-c\t�P�t�@�C�����ɉ�ʂ��N���A����B" ) ;
/*  puts ( "\t-f\t�~���l�ߕ\��" ) ;	@@@ */
  puts ( "\t-i\t�t�@�C�����\��" ) ;
  puts ( "\t-k\t�L�[���͑҂�" ) ;
/*  puts ( "\t-lX,Y\t���[�h�I�t�Z�b�g(���l����)" ) ;	@@@ */
  puts ( "\t-n\t�����\��" ) ;
  puts ( "\t-p\t�p�X�̋�؂��'/'�Ƃ���" ) ;
  puts ( "\t-r\t�X�N���[���������](MAG��)" ) ;
  puts ( "\t-v[n]\t���邳 n(0�`100)[%]" ) ;
#ifdef __EXT_GVRAM__
  puts ( "\t-e\tXEiJ�̊g���O���t�B�b�N��ʂ��g�p����" ) ;
  puts ( "\t-z\t�w�肳�ꂽ�t�@�C���̂��������_����1�������\������" ) ;
#endif
end

/* ---------------------------------------------------------------- */

static void mk_cnvtbl ( void )
begin
  int ix1 , wk1 ;

  for ( ix1 = 0 ; ix1 < 256 ; ix1 ++ ) begin
    wk1 = ( ix1 * disp_value * 32 / 100 ) >> 8 ;
    red_cnv_tbl   [ ix1 ] = wk1 * ( RGB ( 1 , 0 , 0 ) - 1 ) ;
    green_cnv_tbl [ ix1 ] = wk1 * ( RGB ( 0 , 1 , 0 ) - 1 ) ;
    blue_cnv_tbl  [ ix1 ] = wk1 * ( RGB ( 0 , 0 , 1 ) - 1 ) ;
  endfor
end

/* ---------------------------------------------------------------- */

static int x_file_proc ( uchar * fname_pt1 , int no_wild )
begin
  int ret , wlen1 ;
  uchar * wfname , * wpath1 , * ch_pt1 , * ch_pt2 ;
  struct FILBUF fileinfo ;
#ifdef __EXT_GVRAM__
  int file_count, file_selected;
#endif  

  if ( jstrchr ( fname_pt1 , '.' ) == NULL ) then
    wfname = ( uchar * ) alloca ( strlen ( ( char * ) fname_pt1 ) + 5 ) ;
    sprintf ( ( char * ) wfname , "%s.BMP" , fname_pt1 ) ;
    fname_pt1 = wfname ;
  endif_

  if ( no_wild != 0 or
     ( jstrchr ( fname_pt1 , '*' ) == NULL and
       jstrchr ( fname_pt1 , '?' ) == NULL ) ) then

    return ( x_bmp_load ( fname_pt1 ) ) ;
  endif_

  if ( ( ch_pt1 = jstrrchr ( fname_pt1 , path_dlm ) ) != NULL or
       ( ch_pt1 = jstrrchr ( fname_pt1 , ':'  ) ) != NULL ) then

    wlen1 = ch_pt1 - fname_pt1 + 1 ;
    wpath1 = ( uchar * ) alloca ( wlen1 + 23 ) ;
    memcpy ( ( void * ) wpath1 , ( void * ) fname_pt1 , ( size_t ) wlen1 ) ;
    ch_pt1 = wpath1 ;
    ch_pt2 = wpath1 + wlen1 ;
   else_
    ch_pt1 = fileinfo . name ;
    ch_pt2 = NULL ;
  endif_

#ifdef __EXT_GVRAM__
  file_count = 0;
  if ( random_mode != 0 ) then
    ret = FILES ( & fileinfo , fname_pt1 , 0x20 ) ;
    while ( ret == 0 ) begin
      if ( ( fileinfo . atr & 0x02 ) == 0 ) then
        file_count++;
      endif_	
      ret = NFILES ( & fileinfo ) ;
    endwhile
    srand( ( unsigned int ) time ( NULL ) );
    file_selected = rand() % file_count ;
    file_count = 0;
  endif_
#endif

  ret = FILES ( & fileinfo , fname_pt1 , 0x20 ) ;
  while ( ret == 0 ) begin
    if ( ( fileinfo . atr & 0x02 ) == 0 ) then
      if ( ch_pt2 != NULL ) strcpy ( ( void * ) ch_pt2 , ( void * ) fileinfo . name ) ;
#ifdef __EXT_GVRAM__
      if ( random_mode == 0 or file_count == file_selected ) then
        if ( x_bmp_load ( ch_pt1 ) != 0 ) return ( - 1 ) ;
      endif_
#else
      if ( x_bmp_load ( ch_pt1 ) != 0 ) return ( - 1 ) ;
#endif
      if ( exit_flag != 0 ) break ;
#ifdef __EXT_GVRAM__
      file_count++;
#endif
    endif_
    ret = NFILES ( & fileinfo ) ;
  endwhile

  return ( 0 ) ;
end

/* ---------------------------------------------------------------- */

static int x_bmp_load ( uchar * bmp_fname_pt1 )
begin
  int bmp_fh ;
  int bmp_openf , retc ;
  int ox1 , oy1 ;
  int ( * proc_pt1 ) ( ) ;
  BITMAP_FILE_HEADER bmp_fil_hdr ;
  BITMAP_INFO_HEADER bmp_inf_hdr ;

  bmp_openf = 0 ;

  if ( ( bmp_fh = open ( ( char * ) bmp_fname_pt1 , O_RDONLY | O_BINARY ,
      S_IREAD | S_IWRITE ) ) < 0 ) then

    x_ret_crt_mode ( ) ;
    printf ( "%s �̓I�[�v���o���܂���B\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  bmp_openf = 1 ;

  if ( read ( bmp_fh , & bmp_fil_hdr , sizeof ( bmp_fil_hdr ) ) !=
                                       sizeof ( bmp_fil_hdr ) ) goto lb700 ;

  x_swap_bytes ( & bmp_fil_hdr , bmp_fil_hdr_swap ,
                      numberof ( bmp_fil_hdr_swap ) / 2 ) ;

  if ( info_mode != 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "FileName ��������� %s\n"         , bmp_fname_pt1 ) ;
    printf ( "FileType ��������� %04X\n"       , bmp_fil_hdr . bfType ) ;
    printf ( "FileSize ��������� %d [bytes]\n" , bmp_fil_hdr . bfSize ) ;
    printf ( "bfOffBits �������� %d\n"         , bmp_fil_hdr . bfOffBits ) ;
  endif_

  /*if ( bmp_fil_hdr . bfType != 'BM' ) goto lb700 ;*/
  if ( bmp_fil_hdr . bfType != 0x424d ) goto lb700 ;

  if ( read ( bmp_fh , & bmp_inf_hdr , sizeof ( bmp_inf_hdr ) ) !=
                                       sizeof ( bmp_inf_hdr ) ) goto lb700 ;

  x_swap_bytes ( & bmp_inf_hdr , bmp_inf_hdr_swap ,
                      numberof ( bmp_inf_hdr_swap ) / 2 ) ;

  if ( info_mode != 0 ) then
    printf ( "biSize ����������� %d [bytes]\n"        , bmp_inf_hdr . biSize ) ;
    printf ( "biWidth ���������� %d [pixels]\n"       , bmp_inf_hdr . biWidth ) ;
    printf ( "biHeight ��������� %d [pixels]\n"       , bmp_inf_hdr . biHeight ) ;
    printf ( "biPlanes ��������� %d\n"                , bmp_inf_hdr . biPlanes ) ;
    printf ( "biBitCount ������� %d [bits]\n"         , bmp_inf_hdr . biBitCount ) ;
    printf ( "biCompression ���� %d\n"                , bmp_inf_hdr . biCompression ) ;
    printf ( "biSizeImage ������ %d [bytes]\n"        , bmp_inf_hdr . biSizeImage ) ;
    printf ( "biXPelsPerMeter �� %d [pixels/meter]\n" , bmp_inf_hdr . biXPelsPerMeter ) ;
    printf ( "biYPelsPerMeter �� %d [pixels/meter]\n" , bmp_inf_hdr . biYPelsPerMeter ) ;
    printf ( "biClrUsed �������� %d [colors]\n"       , bmp_inf_hdr . biClrUsed ) ;
    printf ( "biClrImportant ��� %d [colors]\n\n"     , bmp_inf_hdr . biClrImportant ) ;
    goto lb500 ;
  endif_

  if ( bmp_inf_hdr . biCompression != 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s �͈��k����Ă���̂őΉ��ł��܂���B\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  switch ( bmp_inf_hdr . biBitCount ) of
  case 1 :	/* 2�F */
  case 4 :	/* 16�F */
  case 8 :	/* 256�F */
  case 24 :	/* 1678���F */
    break ;
  default :
    x_ret_crt_mode ( ) ;
    printf ( "%s ��2�F�A16�F�A256�F����1678���F�f�[�^�ł͂���܂���B\n" ,
             bmp_fname_pt1 ) ;
    goto lb800 ;
  endswitch

  x_chg_crt_mode ( & bmp_inf_hdr ) ;

  if ( bmp_inf_hdr . biBitCount != 24 ) then	/* 1678���F�ȊO */
    if ( x_read_palette ( bmp_fh , bmp_fname_pt1 , & bmp_fil_hdr ,
        & bmp_inf_hdr ) != 0 ) goto lb800 ;
  endif_

  if ( cent_mode == 0 ) then
    ox1 = load_x1 ;
    oy1 = load_y1 ;
   else_
#ifndef __EXT_GVRAM__
    if ( bmp_inf_hdr . biBitCount == 24 ) then		/* 1678���F */
#else
    if ( bmp_inf_hdr . biBitCount == 24 && exg_mode == 0 ) then		/* 1678���F����g�����[�h */
#endif
      if ( ( ox1 = VRAM8_XL - bmp_inf_hdr . biWidth  ) < 0 ) ox1 = 0 ;
      if ( ( oy1 = VRAM8_YL - bmp_inf_hdr . biHeight ) < 0 ) oy1 = 0 ;
    else_
      if ( ( ox1 = SCRN_XL - bmp_inf_hdr . biWidth  ) < 0 ) ox1 = 0 ;
      if ( ( oy1 = SCRN_YL - bmp_inf_hdr . biHeight ) < 0 ) oy1 = 0 ;
    endif_
    ox1 >>= 1 ;
    oy1 >>= 1 ;
  endif_

  switch ( bmp_inf_hdr . biBitCount ) of
  case  1 : proc_pt1 = x_read_image1 ;		break ;		/* 2�F */
  case  4 : proc_pt1 = x_read_image4 ;		break ;		/* 16�F */
  case  8 : proc_pt1 = x_read_image8 ;		break ;		/* 256�F */
#ifndef __EXT_GVRAM__
  case 24 : proc_pt1 = x_read_image24 ;		break ;		/* 1678���F */
#else
  case 24 : proc_pt1 = ( exg_mode == 0 ) ? x_read_image24 : x_read_image24ex ;	break ;		/* 1678���F */
#endif
  endswitch

  if ( ( * proc_pt1 ) ( bmp_fh , bmp_fname_pt1 , & bmp_fil_hdr ,
        & bmp_inf_hdr , ox1 , oy1 ) != 0 ) goto lb800 ;

  bmp_openf = 0 ;
  close ( bmp_fh ) ;		/* �����܂ŗ�����G���[�͖����B */

  switch ( bmp_inf_hdr . biBitCount ) of
  case 8 :					/* 256�F */
    vram_copy ( GVRAM + ( VRAM8_XL * VRAM8_YL + SCRN_XL - VRAM8_XL ) ,
                GVRAM + SCRN_XL - VRAM8_XL ) ;

    if ( x_768x512t ( ) != 0 ) goto lb500 ;	/* 768*512 256�F timer set */
    if ( x_768x512s ( ) != 0 ) goto lb500 ;	/* 768*512 256�F start */
    x_set_abort_exit ( ) ;
    x_key_wait ( 0 , 0 , 0 ) ;
    x_reset_abort_exit ( ) ;
    x_768x512e ( ) ;				/* 768*512 256�F end */
    break ;
  case 24 :					/* 1678���F */
#ifndef __EXT_GVRAM__
    x_key_wait ( 0 , VRAM8_XL - ( SCRN_XL - VRAM8_XL ) / 2 , 0 ) ;
#else
    if ( exg_mode == 0 ) {
      x_key_wait ( 0 , VRAM8_XL - ( SCRN_XL - VRAM8_XL ) / 2 , 0 ) ;
    } else {
      if ( fill_mode != 0 ) x_fill16 ( & bmp_inf_hdr , ox1 , oy1 ) ;
      x_key_wait ( 1 , 0 , 0 ) ;
    }
#endif
    break ;
  default :
    if ( fill_mode != 0 ) x_fill16 ( & bmp_inf_hdr , ox1 , oy1 ) ;
    x_key_wait ( 1 , 0 , 0 ) ;
    break ;
  endswitch

lb500 :
  retc = 0 ;
  goto lb900 ;

lb700 :
  x_ret_crt_mode ( ) ;
  printf ( "%s �� BMP �t�@�C���ł͂���܂���B\n" , bmp_fname_pt1 ) ;

lb800 :
  retc = - 1 ;

lb900 :
  if ( bmp_openf != 0 ) close ( bmp_fh ) ;

  return ( retc ) ;
end

/* ---------------------------------------------------------------- */

static void x_swap_bytes ( void * buf_pt1 , uchar * ctl_pt1 , int cnt1 )
begin
  int cnt2 , wk1 ;
  uchar * ch_pt1 , * ch_pt2 ;

  while ( cnt1 -- ) begin
    ch_pt1 = ( uchar * ) buf_pt1 + * ctl_pt1 ++ ;
    cnt2 = * ctl_pt1 ++ ;
    ch_pt2 = ch_pt1 + cnt2 ;
    cnt2 >>= 1 ;
    while ( cnt2 -- ) begin
      wk1 = * ch_pt1 ;
      * ch_pt1 ++ = * -- ch_pt2 ;
      * ch_pt2 = wk1 ;
    endwhile
  endwhile
end

/* ---------------------------------------------------------------- */

static void x_chg_crt_mode ( BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 )
begin
  if ( scrn_mode == 0 ) then
    C_CUROFF ( ) ;
    C_FNKMOD ( 3 ) ;
    SKEY_MOD ( 0 , 0 , 0 ) ;
    MS_CUROF ( ) ;
    scrn_mode = 1 ;
  endif_

  switch ( bmp_inf_hdr_pt1 -> biBitCount ) of
  case 8 :					/* 256�F */
    if ( clr_mode != 0 or disp_mode != 4 ) then
      x_ret_tx_mode ( ) ;
      C_WIDTH ( 4 ) ;				/* 512x512 256 colors */
      x_768x512m ( ) ;				/* 768x512 256�F mode set */
      disp_mode = 4 ;
    endif_
    break ;
  case 24 :					/* 1678���F */
#ifndef __EXT_GVRAM__
    if ( clr_mode != 0 or disp_mode != 5 ) then
      if ( disp_mode == 5 ) then
        WIPE ( ) ;
       else_
        C_WIDTH ( 5 ) ;				/* 512x512 65536 colors */
        x_65536m ( ) ;				/* 768x512 mode set */
        if ( TGUSEMD ( 1 , - 1 ) != 2 ) then
          TGUSEMD ( 1 , 2 ) ;
          tx_use = 1 ;
          TPALET ( 8 , 1 ) ;
          tx_fill ( 2 , 0 , 0 , SCRN_XL - 1 , SCRN_YL - 1 , 0 ) ;
          tx_fill ( 3 , 0 , 0 , ( SCRN_XL - VRAM8_XL ) / 2 - 1 , SCRN_YL - 1 , 0xFFFF ) ;
          tx_fill ( 3 , ( SCRN_XL - VRAM8_XL ) / 2 , 0 ,
                        ( SCRN_XL - VRAM8_XL ) / 2 + VRAM8_XL - 1 , SCRN_YL - 1 , 0 ) ;
          tx_fill ( 3 , ( SCRN_XL - VRAM8_XL ) / 2 + VRAM8_XL , 0 ,
                        SCRN_XL - 1 , SCRN_YL - 1 , 0xFFFF ) ;
        endif_
        disp_mode = 5 ;
      endif_
    endif_
    x_scroll ( 0 , VRAM8_XL - ( SCRN_XL - VRAM8_XL ) / 2 , 0 ) ;
#else
    if ( exg_mode == 0 ) then
      if ( clr_mode != 0 or disp_mode != 5 ) then
        if ( disp_mode == 5 ) then
          WIPE ( ) ;
         else_
          C_WIDTH ( 5 ) ;				/* 512x512 65536 colors */
          x_65536m ( ) ;				/* 768x512 mode set */
          if ( TGUSEMD ( 1 , - 1 ) != 2 ) then
            TGUSEMD ( 1 , 2 ) ;
            tx_use = 1 ;
            TPALET ( 8 , 1 ) ;
            tx_fill ( 2 , 0 , 0 , SCRN_XL - 1 , SCRN_YL - 1 , 0 ) ;
            tx_fill ( 3 , 0 , 0 , ( SCRN_XL - VRAM8_XL ) / 2 - 1 , SCRN_YL - 1 , 0xFFFF ) ;
            tx_fill ( 3 , ( SCRN_XL - VRAM8_XL ) / 2 , 0 ,
                          ( SCRN_XL - VRAM8_XL ) / 2 + VRAM8_XL - 1 , SCRN_YL - 1 , 0 ) ;
            tx_fill ( 3 , ( SCRN_XL - VRAM8_XL ) / 2 + VRAM8_XL , 0 ,
                          SCRN_XL - 1 , SCRN_YL - 1 , 0xFFFF ) ;
          endif_
          disp_mode = 5 ;
        endif_
      endif_
      x_scroll ( 0 , VRAM8_XL - ( SCRN_XL - VRAM8_XL ) / 2 , 0 ) ;
    else_
      if ( clr_mode != 0 or disp_mode != 1 ) then
        ushort* pallet;
	int sspsave,i;
        x_ret_tx_mode ( ) ;
        /* C_WIDTH ( 5 ) ; */	/* 512x512 65536 colors for pallet reset */

        /* C_WIDTH(5)�Ńp���b�g���������Ă��܂��ƃe�L�X�g�̉�����64�����ɂȂ��Ă��܂� */
	/* �����h�����ߒ��ڃp���b�gRAM�ɐݒ�l������ */
	sspsave = B_SUPER ( 0 ) ;
  	g_scroll(1,0,0); /* ���łɃX�N���[���ʒu�����Z�b�g���Ă��� */
  	pallet = (ushort*)0xE82000;
  	for (i = 1; i <=0x10000; i+=0x0202) {
    	    *pallet++ = (ushort)i;
            *pallet++ = (ushort)i;
        }  
        B_SUPER ( sspsave ) ;

	x_ex65536m();		/* 1024x1024 65536 mode set */
        disp_mode = 1 ;
      endif_
    endif_
#endif
    break ;
  default :
    if ( clr_mode != 0 or disp_mode != 1 ) then
      x_ret_tx_mode ( ) ;
      C_WIDTH ( 1 ) ;                           /* 768x512 16 colors */
      disp_mode = 1 ;
    endif_
    break ;
  endswitch
end

/* ---------------------------------------------------------------- */

static void x_ret_crt_mode ( void )
begin
  switch ( disp_mode ) of
  case 1 :			/* 16�F */
    x_scroll ( 1 , 0 , 0 ) ;
    break ;
  case 4 :			/* 256�F */
  case 5 :			/* 1678���F */
    x_scroll ( 0 , 0 , 0 ) ;
    break ;
  endswitch

  x_ret_tx_mode ( ) ;

  if ( scrn_mode != 0 ) then
    SKEY_MOD ( - 1 , 0 , 0 ) ;
    C_FNKMOD ( 0 ) ;
    C_CURON ( ) ;
    scrn_mode = 0 ;
  endif_
end

/* ---------------------------------------------------------------- */

static void x_ret_tx_mode ( void )
begin
  if ( tx_use != 0 ) then
    tx_fill ( 3 , 0 , 0 , SCRN_XL - 1 , SCRN_YL - 1 , 0 ) ;
    TPALET ( 8 , - 2 ) ;
    TGUSEMD ( 1 , 3 ) ;
    tx_use = 0 ;
  endif_
end

/* ---------------------------------------------------------------- */

static int x_read_palette ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 )
begin
  int rgb_size , cl_max , cl_cnt , cl_no1 ;
  RGB_QUAD * rgb_pt1 ;

  if ( bmp_inf_hdr_pt1 -> biSize != sizeof ( * bmp_inf_hdr_pt1 ) ) then
    if ( lseek ( bmp_fh , ( long ) ( sizeof ( * bmp_fil_hdr_pt1 ) + bmp_inf_hdr_pt1 -> biSize ),
                          SEEK_SET ) < 0 ) then

      x_ret_crt_mode ( ) ;
      printf ( "%s can't seek (color table)\n" , bmp_fname_pt1 ) ;
      goto lb800 ;
    endif_
  endif_

  cl_max = 1 << bmp_inf_hdr_pt1 -> biBitCount ;
  if ( ( cl_cnt = bmp_inf_hdr_pt1 -> biClrUsed ) == 0 or cl_cnt > cl_max ) then
    cl_cnt = cl_max ;
  endif_

  rgb_size = sizeof ( RGB_QUAD ) * cl_cnt ;
  rgb_pt1 = ( RGB_QUAD * ) alloca ( rgb_size ) ;

  if ( read ( bmp_fh , ( void * ) rgb_pt1 , ( size_t ) rgb_size ) != rgb_size ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't read (color table)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  cl_no1 = 0 ;
  while ( cl_cnt -- ) begin
    GPALET ( cl_no1 ++ , RGB ( rgb_pt1 -> rgbRed   * disp_value / 100 >> 3 ,
                               rgb_pt1 -> rgbGreen * disp_value / 100 >> 3 ,
                               rgb_pt1 -> rgbBlue  * disp_value / 100 >> 3 ) ) ;
    rgb_pt1 ++ ;
  endwhile

  return ( 0 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */

static int x_read_image1 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 )
begin
  int sspsave ;
  int img_xl1 , img_xb1 , xcnt1 , xcnt2 ;
  int sxl1 , sxl2 , sxl3 , sy1 , syl1 ;
  int zero , one ;
  signed char wch1 , * img_pt1 ;
  uchar * img_buf1 ;
  T_GVRAM * vram_pt1 , * vram_pt2 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_xb1 = ( ( img_xl1 + 7 ) / 8 + 3 ) & ~ 3 ;
  img_buf1 = ( uchar * ) alloca ( img_xb1 ) ;

  if ( ox1 >= VRAM4_XL ) goto lb500 ;
  if ( ox1 < 0 ) ox1 = 0 ;		/* @@@ */

  sxl1 = img_xl1 ;
  if ( ox1 + sxl1 > VRAM4_XL ) sxl1 = VRAM4_XL - ox1 ;
  sxl2 = sxl1 >> 3 ;
  sxl3 = sxl1 & 7 ;

  if ( oy1 >= VRAM4_YL ) goto lb500 ;
  if ( oy1 < 0 ) oy1 = 0 ;		/* @@@ */

  if ( ( sy1 = oy1 + bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) sy1 = VRAM4_YL ;
  if ( ( syl1 = bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) syl1 = VRAM4_YL ;

  if ( lseek ( ( int ) bmp_fh , ( long ) ( bmp_fil_hdr_pt1 -> bfOffBits ), SEEK_SET ) < 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't seek (image data)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  TGUSEMD ( 0 , 3 ) ;
  sspsave = B_SUPER ( 0 ) ;
  vram_pt1 = GVRAM + sy1 * VRAM4_XL ;
  iobuf_cnt1 = 0 ;
  zero = 0 ;
  one = 1 ;

  while ( syl1 -- ) begin
    if ( x_read ( bmp_fh , img_buf1 , img_xb1 ) != img_xb1 ) goto lb600 ;

    vram_pt1 -= VRAM4_XL ;
    vram_pt2 = vram_pt1 + ox1 ;
    img_pt1 = ( void * ) img_buf1 ;

    xcnt1 = sxl2 ;
    while ( xcnt1 -- ) begin
      if ( ( wch1 = * img_pt1 ++ ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
      if ( ( wch1 <<= 1 ) >= 0 ) * vram_pt2 ++ = zero ; else * vram_pt2 ++ = one ;
    endwhile

    if ( sxl3 != 0 ) then
      wch1 = * img_pt1 ;
      xcnt2 = sxl3 ;
      while ( xcnt2 -- ) begin
        if ( wch1 >= 0 ) then
          * vram_pt2 ++ = zero ;
         else_
          * vram_pt2 ++ = one ;
        endif_
        wch1 <<= 1 ;
      endwhile
    endif_
  endwhile

  B_SUPER ( sspsave ) ;

lb500 :
  return ( 0 ) ;

lb600 :
  B_SUPER ( sspsave ) ;
  x_ret_crt_mode ( ) ;
  printf ( "%s can't read (image data)\n" , bmp_fname_pt1 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */

static int x_read_image4 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 )
begin
  int sspsave ;
  int img_xl1 , img_xb1 , xcnt1 ;
  int sxl1 , sxl2 , sxl3 , sy1 , syl1 , wch1 ;
  uchar * img_buf1 , * img_pt1 ;
  T_GVRAM * vram_pt1 , * vram_pt2 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_xb1 = ( ( img_xl1 + 1 ) / 2 + 3 ) & ~ 3 ;
  img_buf1 = ( uchar * ) alloca ( img_xb1 ) ;

  if ( ox1 >= VRAM4_XL ) goto lb500 ;
  if ( ox1 < 0 ) ox1 = 0 ;		/* @@@ */

  sxl1 = img_xl1 ;
  if ( ox1 + sxl1 > VRAM4_XL ) sxl1 = VRAM4_XL - ox1 ;
  sxl2 = sxl1 >> 1 ;
  sxl3 = sxl1 & 1 ;

  if ( oy1 >= VRAM4_YL ) goto lb500 ;
  if ( oy1 < 0 ) oy1 = 0 ;		/* @@@ */

  if ( ( sy1 = oy1 + bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) sy1 = VRAM4_YL ;
  if ( ( syl1 = bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) syl1 = VRAM4_YL ;

  if ( lseek ( ( int ) bmp_fh , ( long ) ( bmp_fil_hdr_pt1 -> bfOffBits ) , SEEK_SET ) < 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't seek (image data)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  TGUSEMD ( 0 , 3 ) ;
  sspsave = B_SUPER ( 0 ) ;
  vram_pt1 = GVRAM + sy1 * VRAM4_XL ;
  iobuf_cnt1 = 0 ;

  while ( syl1 -- ) begin
    if ( x_read ( bmp_fh , img_buf1 , img_xb1 ) != img_xb1 ) goto lb600 ;

    vram_pt1 -= VRAM4_XL ;
    vram_pt2 = vram_pt1 + ox1 ;
    img_pt1 = img_buf1 ;

    xcnt1 = sxl2 ;
    while ( xcnt1 -- ) begin
      wch1 = * img_pt1 ++ ;
      * vram_pt2 ++ = wch1 >> 4 ;
      * vram_pt2 ++ = wch1 & 0xF ;
    endwhile

    if ( sxl3 != 0 ) then
      * vram_pt2 = * img_pt1 >> 4 ;
    endif_
  endwhile

  B_SUPER ( sspsave ) ;

lb500 :
  return ( 0 ) ;

lb600 :
  B_SUPER ( sspsave ) ;
  x_ret_crt_mode ( ) ;
  printf ( "%s can't read (image data)\n" , bmp_fname_pt1 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */

static int x_read_image8 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 )
begin
  int sspsave ;
  int img_xl1 , img_xl2 , img_yl1 , img_yl2 , img_xb1 , xcnt1 ;
  int sx1 , sx2 , sxl1 , sxl2 , sy1 , syl1 ;
  int ox2 , ox3 , oy2 ;
  ulong oy3 ;
  uchar * img_buf1 , * img_pt1 ;
  T_GVRAM * vram_pt1 , * vram_pt2 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_xb1 = ( img_xl1 + 3 ) & ~ 3 ;
  img_buf1 = ( uchar * ) alloca ( img_xb1 ) ;

  if ( ( ox2 = ox1 ) >= 0 ) then
    if ( ox1 >= SCRN_XL ) goto lb500 ;
    ox3 = 0 ;
    img_xl2 = img_xl1 ;
   else_
    ox2 = 0 ;			/* vram�� offset */
    ox3 = - ox1 ;		/* image�� offset */
    img_xl2 = img_xl1 + ox1 ;	/* �C�� image�T�C�Y */
    if ( img_xl2 <= 0 ) goto lb500 ;
  endif_

  if ( ( sx1 = ox2 ) > VRAM8_XL ) then
    sx1 = VRAM8_XL ;
    if ( ( sx2 = ox2 - VRAM8_XL ) > ( SCRN_XL - VRAM8_XL ) ) then
      sx2 = SCRN_XL - VRAM8_XL ;
    endif_
   else_
    sx2 = 0 ;
  endif_

  sxl1 = img_xl2 ;
  if ( sx1 + sxl1 > VRAM8_XL ) then
    sxl1 = VRAM8_XL - sx1 ;
    sxl2 = img_xl2 - sxl1 ;
    if ( sx2 + sxl2 > ( SCRN_XL - VRAM8_XL ) ) then
      sxl2 = ( SCRN_XL - VRAM8_XL ) - sx2 ;
    endif_
   else_
    sxl2 = 0 ;
  endif_

  img_yl1 = bmp_inf_hdr_pt1 -> biHeight ;

  if ( ( oy2 = oy1 ) >= 0 ) then
    if ( oy1 >= SCRN_YL ) goto lb500 ;
    img_yl2 = img_yl1 ;
   else_
    oy2 = 0 ;			/* vram�� offset */
    img_yl2 = img_yl1 + oy1 ;	/* �C�� image�T�C�Y */
    if ( img_yl2 <= 0 ) goto lb500 ;
  endif_

  syl1 = img_yl2 ;
  if ( ( sy1 = oy2 + img_yl2 ) > VRAM8_YL ) then
    oy3 = ( ulong ) ( sy1 - VRAM8_YL ) * img_xb1 ;
    syl1 = VRAM8_YL - oy2 ;
    sy1 = VRAM8_YL ;
   else_
    oy3 = 0 ;
  endif_

  if ( lseek ( ( int ) bmp_fh , ( long ) ( bmp_fil_hdr_pt1 -> bfOffBits + oy3 ) , SEEK_SET ) < 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't seek (image data)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  TGUSEMD ( 0 , 3 ) ;
  sspsave = B_SUPER ( 0 ) ;
  vram_pt1 = GVRAM + sy1 * VRAM8_XL ;
  iobuf_cnt1 = 0 ;

  while ( syl1 -- ) begin
    if ( x_read ( bmp_fh , img_buf1 , img_xb1 ) != img_xb1 ) goto lb600 ;

    vram_pt1 -= VRAM8_XL ;
    vram_pt2 = vram_pt1 + sx1 ;
    img_pt1 = img_buf1 + ox3 ;

    if ( sxl1 > 0 ) then
      xcnt1 = sxl1 ;
      while ( xcnt1 -- ) * vram_pt2 ++ = * img_pt1 ++ ;
    endif_

    if ( sxl2 > 0 ) then
      vram_pt2 = vram_pt1 + VRAM8_XL * VRAM8_YL + sx2 ;
      xcnt1 = sxl2 ;
      while ( xcnt1 -- ) * vram_pt2 ++ = * img_pt1 ++ ;
    endif_
  endwhile

  B_SUPER ( sspsave ) ;

lb500 :
  return ( 0 ) ;

lb600 :
  B_SUPER ( sspsave ) ;
  x_ret_crt_mode ( ) ;
  printf ( "%s can't read (image data)\n" , bmp_fname_pt1 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */

static int x_read_image24 ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 )
begin
  int sspsave ;
  int img_xl1 , img_yl1 , img_xb1 ;
  int ox2 , oy2 , ox3 , oy3 , sxl1 , syl1 , sy1 ;
  uchar * img_buf1 ;
  T_GVRAM * vram_pt1 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_xb1 = ( img_xl1 * 3 + 3 ) & ~ 3 ;
  img_buf1 = ( uchar * ) alloca ( img_xb1 ) ;

  if ( ( ox2 = ox1 ) >= 0 ) then
    if ( ox1 >= VRAM8_XL ) goto lb500 ;
    ox3 = 0 ;
    sxl1 = img_xl1 ;
   else_
    ox2 = 0 ;			/* vram�� offset */
    ox3 = ( - ox1 ) * 3 ;	/* image�� offset */
    sxl1 = img_xl1 + ox1 ;	/* �C�� image�T�C�Y */
    if ( sxl1 <= 0 ) goto lb500 ;
  endif_

  if ( ox2 + sxl1 > VRAM8_XL ) sxl1 = VRAM8_XL - ox2 ;

  img_yl1 = bmp_inf_hdr_pt1 -> biHeight ;

  if ( ( oy2 = oy1 ) >= 0 ) then
    if ( oy1 >= VRAM8_YL ) goto lb500 ;
    syl1 = img_yl1 ;
   else_
    oy2 = 0 ;			/* vram�� offset */
    syl1 = img_yl1 + oy1 ;	/* �C�� image�T�C�Y */
    if ( syl1 <= 0 ) goto lb500 ;
  endif_

  if ( ( sy1 = oy2 + syl1 ) > VRAM8_YL ) then
    oy3 = ( ulong ) ( sy1 - VRAM8_YL ) * img_xb1 ;
    syl1 = VRAM8_YL - oy2 ;
    sy1 = VRAM8_YL ;
   else_
    oy3 = 0 ;
  endif_

  if ( lseek ( ( int ) bmp_fh , ( long ) ( bmp_fil_hdr_pt1 -> bfOffBits + oy3 ) , SEEK_SET ) < 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't seek (image data)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  TGUSEMD ( 0 , 3 ) ;
  sspsave = B_SUPER ( 0 ) ;
  vram_pt1 = GVRAM + sy1 * VRAM8_XL ;
  iobuf_cnt1 = 0 ;

  while ( syl1 -- ) begin
    if ( x_read ( bmp_fh , img_buf1 , img_xb1 ) != img_xb1 ) goto lb600 ;
    vram_pt1 -= VRAM8_XL ;
    x_store_image24 ( vram_pt1 + ox2 , img_buf1 + ox3 , sxl1 ) ;
  endwhile

  B_SUPER ( sspsave ) ;

lb500 :
  return ( 0 ) ;

lb600 :
  B_SUPER ( sspsave ) ;
  x_ret_crt_mode ( ) ;
  printf ( "%s can't read (image data)\n" , bmp_fname_pt1 ) ;

lb800 :
  return ( - 1 ) ;
end

/* ---------------------------------------------------------------- */
#ifdef __EXT_GVRAM__
static int x_read_image24ex ( int bmp_fh , uchar * bmp_fname_pt1 ,
    BITMAP_FILE_HEADER * bmp_fil_hdr_pt1 , BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 ,
    int ox1 , int oy1 )
begin
  int sspsave ;
  int img_xl1 , img_xb1 , xcnt1 ;
  int sxl1 , sxl2 , sxl3 , sy1 , syl1 , wblue1, wgreen1, wred1;
  uchar * img_buf1 , * img_pt1 ;
  T_GVRAM * vram_pt1 , * vram_pt2 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_xb1 = ( img_xl1 * 3 + 3 ) & ~ 3 ;
  img_buf1 = ( uchar * ) alloca ( img_xb1 ) ;

  if ( ox1 >= VRAM4_XL ) goto lb500 ;
  if ( ox1 < 0 ) ox1 = 0 ;		/* @@@ */

  sxl1 = img_xl1 ;
  if ( ox1 + sxl1 > VRAM4_XL ) sxl1 = VRAM4_XL - ox1 ;
  sxl2 = sxl1 >> 1 ;
  sxl3 = sxl1 & 1 ;

  if ( oy1 >= VRAM4_YL ) goto lb500 ;
  if ( oy1 < 0 ) oy1 = 0 ;		/* @@@ */

  if ( ( sy1 = oy1 + bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) sy1 = VRAM4_YL ;
  if ( ( syl1 = bmp_inf_hdr_pt1 -> biHeight ) > VRAM4_YL ) syl1 = VRAM4_YL ;

  if ( lseek ( ( int ) bmp_fh , ( long ) ( bmp_fil_hdr_pt1 -> bfOffBits ) , SEEK_SET ) < 0 ) then
    x_ret_crt_mode ( ) ;
    printf ( "%s can't seek (image data)\n" , bmp_fname_pt1 ) ;
    goto lb800 ;
  endif_

  TGUSEMD ( 0 , 3 ) ;
  sspsave = B_SUPER ( 0 ) ;

  vram_pt1 = GVRAM + sy1 * VRAM4_XL ;
  iobuf_cnt1 = 0 ;

  while ( syl1 -- ) begin
    if ( x_read ( bmp_fh , img_buf1 , img_xb1 ) != img_xb1 ) goto lb600 ;
    vram_pt1 -= VRAM4_XL ;
    x_store_image24 ( vram_pt1 + ox1 , img_buf1 , sxl1 );
  endwhile

  B_SUPER ( sspsave ) ;

lb500 :
  return ( 0 ) ;

lb600 :
  B_SUPER ( sspsave ) ;
  x_ret_crt_mode ( ) ;
  printf ( "%s can't read (image data)\n" , bmp_fname_pt1 ) ;

lb800 :
  return ( - 1 ) ;
end
#endif

/* ---------------------------------------------------------------- */

static void x_store_image24 ( T_GVRAM * vram_pt1 , uchar * img_pt1 , int sxl1 )
begin
  int xcnt1 ;
  int wred1 , wgreen1 , wblue1 ;

  xcnt1 = sxl1 ;
  while ( xcnt1 -- ) begin
    wblue1  = * img_pt1 ++ ;
    wgreen1 = * img_pt1 ++ ;
    wred1   = * img_pt1 ++ ;
    * vram_pt1 ++ = 
        blue_cnv_tbl  [ wblue1  ] +
        green_cnv_tbl [ wgreen1 ] +
        red_cnv_tbl   [ wred1   ] ;
  endwhile
end

/* ---------------------------------------------------------------- */

static int x_read ( int fh1 , uchar * buf_pt1 , int wlen1 )
begin
  int wlen2 ;
  uchar * buf_pt2 ;

  buf_pt2 = buf_pt1 ;

  while ( wlen1 > 0 ) begin
    if ( iobuf_cnt1 <= 0 ) then
      if ( ( iobuf_cnt1 = read ( ( int ) fh1 , ( void * ) iobuf1 , ( size_t ) IOBUF_SZ1 ) ) <= 0 ) break ;
      iobuf_pt1 = iobuf1 ;
    endif_
    if ( ( wlen2 = wlen1 ) > iobuf_cnt1 ) wlen2 = iobuf_cnt1 ;
    memcpy ( ( void * ) buf_pt2 , ( void * ) iobuf_pt1 , ( size_t ) wlen2 ) ;
    buf_pt2 += wlen2 ;
    iobuf_pt1 += wlen2 ;
    iobuf_cnt1 -= wlen2 ;
    wlen1 -= wlen2 ;
  endwhile

  return ( buf_pt2 - buf_pt1 ) ;
end

/* ---------------------------------------------------------------- */

static void vram_copy ( T_GVRAM * vram_pt1 , T_GVRAM * vram_pt2 )
begin
  int sspsave ;
  int ycnt1 ;

  sspsave = B_SUPER ( 0 ) ;

  ycnt1 = VRAM8_YL ;
  while ( ycnt1 -- ) begin
    quick_copy ( vram_pt1 , vram_pt2 , VRAM8_XL / 2 ) ;
    vram_pt1 += VRAM8_XL ;
    vram_pt2 += VRAM8_XL ;
  endwhile

  B_SUPER ( sspsave ) ;
end

/* ----------------------------------------------------------------- */

static void x_set_abort_exit ( void )
begin
  xc_abort_proc1 = ( void ( * ) ( void ) ) INTVCS ( 0xFFF1 , ( char * ) my_abort_proc1 ) ;
  xc_abort_proc2 = ( void ( * ) ( void ) ) INTVCS ( 0xFFF2 , ( char * ) my_abort_proc2 ) ;
end

/* ----------------------------------------------------------------- */

static void x_reset_abort_exit ( void )
begin
  INTVCS ( 0xFFF1 , ( char * ) xc_abort_proc1 ) ;
  INTVCS ( 0xFFF2 , ( char * ) xc_abort_proc2 ) ;
end

/* ----------------------------------------------------------------- */

static void my_abort_proc1 ( void )
begin
  x_768x512e ( ) ;	/* 768*512 256�F end */
  C_FNKMOD ( 0 ) ;
  C_CURON ( ) ;

  ( * xc_abort_proc1 ) ( ) ;
end

/* ----------------------------------------------------------------- */

static void my_abort_proc2 ( void )
begin
  x_768x512e ( ) ;	/* 768*512 256�F end */
  C_FNKMOD ( 0 ) ;
  C_CURON ( ) ;

  ( * xc_abort_proc2 ) ( ) ;
end

/* ---------------------------------------------------------------- */

static void x_fill16 ( BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 , int ox1 , int oy1 )
begin
  int img_xl1 , img_yl1 ;
  int nx1 , ny1 , nx2 , ny2 , sx1 , sy1 , sx2 , sy2 , ix1 , iy1 ;
  int sspsave ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_yl1 = bmp_inf_hdr_pt1 -> biHeight ;

  if ( ox1 < 0 ) ox1 = 0 ;	/* @@@ */
  if ( oy1 < 0 ) oy1 = 0 ;

  nx1 = ox1 / img_xl1 ;
  if ( ( sx1 = ox1 % img_xl1 ) > 0 ) then
    nx1 ++ ;
    sx1 = img_xl1 - sx1 ;
  endif_
  nx2 = ( VRAM4_XL + sx1 + img_xl1 - 1 ) / img_xl1 ;

  if ( img_yl1 > VRAM4_YL ) then	/* @@@ */
    ny1 = 0 ;
    ny2 = 1 ;
    sy1 = img_yl1 - VRAM4_YL ;
    oy1 = - sy1 ;
   else_
    ny1 = oy1 / img_yl1 ;
    if ( ( sy1 = oy1 % img_yl1 ) > 0 ) then
      ny1 ++ ;
      sy1 = img_yl1 - sy1 ;
    endif_
    ny2 = ( VRAM4_YL + sy1 + img_yl1 - 1 ) / img_yl1 ;
  endif_

  sspsave = B_SUPER ( 0 ) ;
  sy2 = - sy1 ;

  for ( iy1 = 0 ; iy1 < ny2 ; iy1 ++ ) begin
    sx2 = - sx1 ;
    for ( ix1 = 0 ; ix1 < nx2 ; ix1 ++ ) begin
      if ( ix1 != nx1 or iy1 != ny1 ) then
        img_copy16 ( sx2 , sy2 , ox1 , oy1 , bmp_inf_hdr_pt1 ) ;
      endif_
      sx2 += img_xl1 ;
    endfor
    sy2 += img_yl1 ;
  endfor

  B_SUPER ( sspsave ) ;
end

/* ---------------------------------------------------------------- */

static void img_copy16 ( int sx1 , int sy1 , int sx2 , int sy2 ,
    BITMAP_INFO_HEADER * bmp_inf_hdr_pt1 )
begin
  int img_xl1 , img_yl1 ;
  int ox1 , oy1 , sxl1 , syl1 ;
  T_GVRAM * vram_pt1 , * vram_pt2 ;

  img_xl1 = bmp_inf_hdr_pt1 -> biWidth ;
  img_yl1 = bmp_inf_hdr_pt1 -> biHeight ;

  if ( sx1 < 0 ) then
    ox1 = - sx1 ;
   else_
    ox1 = 0 ;
  endif_

  if ( sx1 + img_xl1 > VRAM4_XL ) then
    sxl1 = VRAM4_XL - sx1 - ox1 ;
   else_
    sxl1 = img_xl1 - ox1 ;
  endif_

  if ( sy1 < 0 ) then
    oy1 = - sy1 ;
   else_
    oy1 = 0 ;
  endif_

  if ( sy1 + img_yl1 > VRAM4_YL ) then
    syl1 = VRAM4_YL - sy1 - oy1 ;
   else_
    syl1 = img_yl1 - oy1 ;
  endif_

  vram_pt1 = GVRAM + ( sy1 + oy1 ) * VRAM4_XL + sx1 + ox1 ;
  vram_pt2 = GVRAM + ( sy2 + oy1 ) * VRAM4_XL + sx2 + ox1 ;

  while ( syl1 -- ) begin
    quick_copy ( vram_pt1 , vram_pt2 , sxl1 ) ;
    vram_pt1 += VRAM4_XL ;
    vram_pt2 += VRAM4_XL ;
  endwhile
end

/* ----------------------------------------------------------------- */

static void quick_copy ( T_GVRAM * vram_pt1 , T_GVRAM * vram_pt2 , int wlen1 )
begin
  int wcnt1 , wcnt2 ;
  ulong * long_pt1 , * long_pt2 ;

  wcnt1 = wlen1 / ( sizeof ( ulong ) / sizeof ( T_GVRAM ) * 4 ) ;
  wcnt2 = wlen1 % ( sizeof ( ulong ) / sizeof ( T_GVRAM ) * 4 ) ;

  long_pt1 = ( ulong * ) vram_pt1 ;
  long_pt2 = ( ulong * ) vram_pt2 ;

  while ( wcnt1 -- ) begin
    * long_pt1 ++ = * long_pt2 ++ ;
    * long_pt1 ++ = * long_pt2 ++ ;
    * long_pt1 ++ = * long_pt2 ++ ;
    * long_pt1 ++ = * long_pt2 ++ ;
  endwhile

  vram_pt1 = ( T_GVRAM * ) long_pt1 ;
  vram_pt2 = ( T_GVRAM * ) long_pt2 ;

  while ( wcnt2 -- ) * vram_pt1 ++ = * vram_pt2 ++ ;
end

/* ---------------------------------------------------------------- */

static void x_key_wait ( int wmode1 , int ox1 , int oy1 )
begin
  int sspsave ;
  int wcnt1 , wcnt2 , wsts1 , wsts2 ;
  int sx1 , sy1 , wch1 , wfunc1 , wgrp1 , wbit1 ;

  sspsave = B_SUPER ( 0 ) ;

  sx1 = ox1 ;
  sy1 = oy1 ;
  g_scroll ( wmode1 , sx1 , sy1 ) ;
  wcnt1 = 0 ;
  wsts1 = * ( uchar * ) 0xE88001 & 0x10 ;

  loop
    if ( wait_mode != 0 or B_KEYSNS ( ) != 0 ) then
      if ( ( wch1 = B_KEYINP ( ) & 0xFF00 ) == 0x3500 or
             wch1 == 0x1D00 or wch1 == 0x4E00 ) break ;

      if ( wch1 == 0x0100 or ( wch1 >= 0x6100 and wch1 <= 0x6C00 ) ) then
        exit_flag = 1 ;
        break ;
      endif_

      switch ( wch1 ) of
      case 0x3600 : wfunc1 = 0 ;				break ;	/* home */
      case 0x3D00 : wfunc1 = 1 ;     wgrp1 = 7 ; wbit1 = 0x20 ;	break ;	/* right */
      case 0x3B00 : wfunc1 = 2 ;     wgrp1 = 7 ; wbit1 = 0x08 ;	break ;	/* left */
      case 0x3E00 : wfunc1 = 4 ;     wgrp1 = 7 ; wbit1 = 0x40 ;	break ;	/* down */
      case 0x3C00 : wfunc1 = 8 ;     wgrp1 = 7 ; wbit1 = 0x10 ;	break ;	/* up */
      case 0x4B00 : wfunc1 = 2 + 4 ; wgrp1 = 9 ; wbit1 = 0x08 ;	break ;	/* 1 */
      case 0x4C00 : wfunc1 = 4 ;     wgrp1 = 9 ; wbit1 = 0x10 ;	break ;	/* 2 */
      case 0x4D00 : wfunc1 = 1 + 4 ; wgrp1 = 9 ; wbit1 = 0x20 ;	break ;	/* 3 */
      case 0x4700 : wfunc1 = 2 ;     wgrp1 = 8 ; wbit1 = 0x80 ;	break ;	/* 4 */
      case 0x4800 : wfunc1 = 0 ;				break ;	/* 5 */
      case 0x4900 : wfunc1 = 1 ;     wgrp1 = 9 ; wbit1 = 0x02 ;	break ;	/* 6 */
      case 0x4300 : wfunc1 = 2 + 8 ; wgrp1 = 8 ; wbit1 = 0x08 ;	break ;	/* 7 */
      case 0x4400 : wfunc1 = 8 ;     wgrp1 = 8 ; wbit1 = 0x10 ;	break ;	/* 8 */
      case 0x4500 : wfunc1 = 1 + 8 ; wgrp1 = 8 ; wbit1 = 0x20 ;	break ;	/* 9 */
      default :     wfunc1 = - 1 ;				break ;
      endswitch

      if ( wfunc1 > 0 ) then
        if ( rev_mode != 0 ) then	/* �X�N���[���������](MAG��) */
          if ( ( wfunc1 & 0x3 ) != 0 ) wfunc1 ^= 0x3 ;
          if ( ( wfunc1 & 0xC ) != 0 ) wfunc1 ^= 0xC ;
        endif_

        wcnt2 = 0 ;
        wsts1 = * ( uchar * ) 0xE88001 & 0x10 ;
        do begin
          wsts2 = * ( uchar * ) 0xE88001 & 0x10 ;
          if ( wsts1 != 0 and wsts2 == 0 ) then		/* �����\������ �� �A���������� */
            wcnt2 = 10 ;				/* �X�N���[���X�s�[�h�̒��� */
          endif_

          if ( wcnt2 > 0 ) then
            if ( ( wfunc1 & 1 ) != 0 ) then
              if ( -- sx1 < 0 ) sx1 += VRAM4_XL ;
            elseif ( ( wfunc1 & 2 ) != 0 ) then
              if ( ++ sx1 >= VRAM4_XL ) sx1 -= VRAM4_XL ;
            endif_
            if ( ( wfunc1 & 4 ) != 0 ) then
              if ( -- sy1 < 0 ) sy1 += VRAM4_YL ;
            elseif ( ( wfunc1 & 8 ) != 0 ) then
              if ( ++ sy1 >= VRAM4_YL ) sy1 -= VRAM4_YL ;
            endif_
            g_scroll ( wmode1 , sx1 , sy1 ) ;
            wcnt2 -- ;
          endif_
          wsts1 = wsts2 ;

          if ( B_KEYSNS ( ) != 0 ) B_KEYINP ( ) ;
        end while ( ( BITSNS ( wgrp1 ) & wbit1 ) != 0 ) ;
      elseif ( wfunc1 == 0 ) then
        sx1 = ox1 ;
        sy1 = oy1 ;
        g_scroll ( wmode1 , sx1 , sy1 ) ;
      endif_
     else_
      wsts2 = * ( uchar * ) 0xE88001 & 0x10 ;
      if ( wsts1 != 0 and wsts2 == 0 ) then
        if ( ++ wcnt1 >= 55 ) break ;
      endif_
      wsts1 = wsts2 ;
    endif_
  endloop

  B_SUPER ( sspsave ) ;
end

/* ---------------------------------------------------------------- */

static void x_scroll ( int wmode1 , int sx1 , int sy1 )
begin
  int sspsave ;

  sspsave = B_SUPER ( 0 ) ;
  g_scroll ( wmode1 , sx1 , sy1 ) ;
  B_SUPER ( sspsave ) ;
end

/* ---------------------------------------------------------------- */

static void g_scroll ( int wmode1 , int sx1 , int sy1 )
begin
  ulong lwk1 ;
  ulong * scrl_pt1 ;

  lwk1 = ( sx1 << 16 ) + sy1 ;

  if ( wmode1 == 0 ) then	/* 256�F */
    scrl_pt1 = ( ulong * ) 0xE80018 ;
    * scrl_pt1 ++ = lwk1 ;
    * scrl_pt1 ++ = lwk1 ;
    * scrl_pt1 ++ = lwk1 ;
    * scrl_pt1 = lwk1 ;
   else_
    * ( ulong * ) 0xE80018 = lwk1 ;
  endif_
end

/* ---------------------------------------------------------------- */

static void tx_fill ( int pg1 , int sx1 , int sy1 , int ex1 , int ey1 , int pt1 )
begin
  struct TXFILLPTR wparm1 ;

  wparm1 . vram_page = pg1 ;
  wparm1 . x = sx1 ;
  wparm1 . y = sy1 ;
  wparm1 . x1 = ex1 - sx1 + 1 ;
  wparm1 . y1 = ey1 - sy1 + 1 ;
  wparm1 . fill_patn = pt1 ;
  TXFILL ( & wparm1 ) ;
end

/* ---------------------------------------------------------------- */
asm ( "\t.quad" ) ;
/* ---------------------------------------------------------------- */

